import "./Footer.css"
const Footer = () => {
  return (
    <footer className="footer">
      FOOTER
    </footer>
  )
}

export default Footer
