const Oops = () => {
  return (
    <div >
      <h3>ERROR 404</h3>
      <p>Not found</p>
    </div>
  )
}

export default Oops
