const AdminDashboard = () => {
  return (
    <div className="content">
      <div className="container">
        DASHBOARD ADMIN
      </div>
    </div>
  )
}

export default AdminDashboard
