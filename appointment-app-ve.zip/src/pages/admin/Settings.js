const Settings = () => {
  return (
    <div className="content">
      <div className="container">
        <h2>SETTINGS</h2>
      </div>
    </div>
  )
}

export default Settings
