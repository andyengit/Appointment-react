import RegisterDoctor from "../../Components/New/RegisterDoctor"

const SignIn = () => {
  return (
    <div className="content">
      <RegisterDoctor />
    </div>
  )
}

export default SignIn
