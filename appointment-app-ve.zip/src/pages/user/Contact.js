function Contact() {
  return (
    <div>
      <h3>CONTACT</h3>
    </div>
  )
}

export default Contact
