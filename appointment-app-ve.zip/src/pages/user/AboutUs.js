function AboutUs() {
  return (
    <div>
      <h3>ACERCA DE NOSOTROS</h3>
    </div>
  )
}

export default AboutUs
